package com.example.frontendtoll;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class CheckBalance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_balance);
        TextView textView;
        textView = findViewById(R.id.balanceCB);
        String balance = getIntent().getStringExtra("balance");
        textView.setText(" Your Balance is "+balance);
    }
}