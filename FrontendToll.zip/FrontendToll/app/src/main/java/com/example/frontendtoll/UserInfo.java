package com.example.frontendtoll;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.example.frontendtoll.R.id.eth;
import static com.example.frontendtoll.R.id.fill;

public class UserInfo extends AppCompatActivity {
    TextView name,ethA,lic,fstatus;
    ImageButton btnS;
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        final String urlSignOut = "http://192.168.43.227:3000/toll/revokeUser";
        final String eth = getIntent().getStringExtra("ethAddress");
        String license = getIntent().getStringExtra("license");
        String idUsr = getIntent().getStringExtra("usr");

        name = findViewById(R.id.name);
        ethA = findViewById(R.id.eth);
        lic = findViewById(R.id.license);
        fstatus = findViewById(R.id.fstatus);
        btnS = findViewById(R.id.signUI);

        name.setText(idUsr);
        ethA.setText(eth);
        lic.setText(license);
        fstatus.setText("Completed");

        btnS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestQueue = Volley.newRequestQueue(UserInfo.this);
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, urlSignOut, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Log.d("UserInfoR","Response is "+response.toString());
                            if(response.getString("success") == "true"){
                                Toast.makeText(UserInfo.this, "Sign Out Successfully", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(UserInfo.this, MainActivity.class);
                                startActivity(intent);
                            }
                            else{
                                Toast.makeText(UserInfo.this, "Something went wrong.. Pls try again", Toast.LENGTH_LONG).show();
                            }
                        }catch (Exception e){
                            e.getStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("UserInfoR", "Error in response Body "+ error.toString());

                    }
                }){
                    @Override
                    public byte[] getBody() {
                        HashMap<String, String> hm =new HashMap<>();
                        hm.put("ethAddress", eth);
                        return new JSONObject(hm).toString().getBytes();
                    }
                    @Override
                    public Map<String, String> getHeaders ()
                            throws AuthFailureError {
                        Map<String, String> params = new HashMap<String,
                                String>();
                        params.put("Content-Type", "application/json");
                        return params;
                    }
                };
                requestQueue.add(jsonObjectRequest);
            }
        });
    }
}