package com.example.frontendtoll;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class TollActivity extends AppCompatActivity {
    ImageView profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toll);

        String result = getIntent().getStringExtra("IDUser");
        String uri = getIntent().getStringExtra("purl");
        profile = findViewById(R.id.imageView);
        Glide.with(this).load(uri).into(profile);
        Log.d("Check","Msg "+ uri);

        TextView textView = findViewById(R.id.textView);
        textView.setText("Welcome "+ result);
    }
}