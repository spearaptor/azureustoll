package com.example.frontendtoll;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class UserOrToll extends AppCompatActivity {
    Button btnU, btnT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_or_toll);
        final String result = getIntent().getStringExtra("IDUser");
        final String uri = getIntent().getStringExtra("purl");
        final String email = getIntent().getStringExtra("email");
        btnU=findViewById(R.id.USER);
        btnU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserOrToll.this, LicenseActivity.class);
                intent.putExtra("IDUser", result);
                intent.putExtra("purl", uri);
                intent.putExtra("email",email);
                startActivity(intent);
            }
        });
        btnT=findViewById(R.id.TOLL);
        btnT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserOrToll.this, TollActivity.class);
                intent.putExtra("IDUser", result);
                intent.putExtra("purl", uri);
                intent.putExtra("email",email);
                startActivity(intent);
            }
        });
    }
}